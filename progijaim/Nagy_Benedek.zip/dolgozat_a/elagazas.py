
def bekert_szoveg():
    szo1 =input('Kérek egy szót:')
    szo2 = input('Kérek egy másik szót:')
    if(len(szo1) == len(szo2)):
        print("\tEgyenlő hosszúak." + str(len(szo1)))
    elif(len(szo1) > len(szo2)):
        print("\tA hosszabb szó a: "+ szo1 +"\n \tA szavak hosszának különbsége:"+ str(len(szo1)-len(szo2)))
    else:
        print("\tA hosszabb szó a: "+ szo2 +"\n \tA szavak hosszának különbsége:"+ str(len(szo2)-len(szo1)))





