#import elagazas
#elagazas.bekert_szoveg()
#import sorozat
# sorozat.RandomNumber(15)
import oop_feladat
oop_feladat.openGreenawayFile()
