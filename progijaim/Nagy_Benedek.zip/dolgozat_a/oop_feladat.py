import greenaway_o
def openGreenawayFile():
  films = []
  fh = open('C:\\greenaway.txt',encoding='utf8').readlines()
  firstLine = fh.pop(0)  # removes the first line
  for line in fh:
    row = line.split('-')
    _cim, _ev,  = [i.strip() for i in row]
    film = greenaway_o.Film(cim=_cim, ev=int(_ev))
    films = films + [film]

  print("Filmek száma: "+str(len(films)))
  #for data in films:
  #  print(data.cim.upper())

  if any("SZAKÁCS" in s.cim.upper() for s in films):
    print("Van olyan cím amiben szerepel a szakács szó.")
  else:
    print("Nincs szakács..")