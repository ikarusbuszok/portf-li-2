import random
def RandomNumber(n):
    randomlist = []
    for i in range(0, n):
        _randomNumber = random.randint(100, 200)
        randomlist.append(_randomNumber)

    formatrandomlist = '%'.join(str(item) for item in randomlist)
    print(formatrandomlist)
    print("A sorozat legkisebb eleme:", min(randomlist))
    with open(r'C:/legkisebb.txt', 'w') as fp:
        fp.write(formatrandomlist)
